//! Explicit classification and one-time actual E/F consumption CAS.
use super::{
    sources::{self, Catalog},
    store::{self, Table},
};
use crate::{
    approval_common::CommonSession,
    auth::model::clock_now,
    contract_support::{Actor, Error, canonical_hash, new_uuid},
    project_operating_common::model::{CostDecisionInput, OperatingMoneyCents},
};
use chrono::NaiveDate;
use serde_json::{Value, json};
use std::collections::{BTreeMap, BTreeSet};
use uuid::Uuid;

pub(crate) fn unit_key(table: Table, row: &Value) -> Result<String, Error> {
    Ok(format!(
        "{}:{}",
        if table == Table::Cost {
            "cost"
        } else {
            "allocation"
        },
        store::id(row, "id")?
    ))
}
pub(crate) fn current_decision<'a>(
    catalog: &'a Catalog,
    project: Uuid,
    key: &str,
) -> Option<&'a Value> {
    catalog
        .all(Table::DecisionHead)
        .iter()
        .find(|h| h["project_id"] == project.to_string() && h["unit_key"] == key)
        .and_then(|h| catalog.by(Table::Decision, "id", &h["decision_id"]))
}
pub(crate) fn canonical_key(cost: &Value) -> Result<String, Error> {
    Ok(if cost["source_type"] == "labor" {
        format!("labor:{}", store::id(cost, "id")?)
    } else {
        format!(
            "{}:{}",
            store::text(cost, "source_type")?,
            store::id(cost, "source_id")?
        )
    })
}
pub(crate) fn chain_key(cost: &Value) -> Result<String, Error> {
    if cost["source_type"] == "payable-record" {
        return Ok(format!("payable:{}", store::id(cost, "source_id")?));
    }
    if let Some(id) = cost["source_basis"]["payableRecordId"].as_str() {
        return Ok(format!("payable:{id}"));
    }
    canonical_key(cost)
}

pub(crate) async fn qualify_cost(
    session: &mut CommonSession<'_, '_>,
    catalog: &Catalog,
    cost: &Value,
    cutoff: NaiveDate,
) -> Result<(), Error> {
    if !matches!(
        cost["record_status"].as_str(),
        Some("confirmed" | "included")
    ) || cost["basis_origin"] != "captured"
        || cost["confirmed_at"].is_null()
        || cost["confirmed_by"].is_null()
    {
        return Err(store::conflict("operating_cost_not_confirmed"));
    }
    if sources::business_day(&cost["occurred_on"])? > cutoff {
        return Err(store::conflict("operating_cost_outside_cutoff"));
    }
    let facts = crate::project_actual_cost::source_facts(session.connection, cost, false).await?;
    for (old, new) in [
        ("amount_excluding_tax", "amountExcludingTax"),
        ("tax_cost_amount", "taxCostAmount"),
        ("amount_including_tax", "amountIncludingTax"),
    ] {
        let a = OperatingMoneyCents::parse_exact(store::text(cost, old)?, old)?;
        let b = OperatingMoneyCents::parse_exact(store::text(&facts, new)?, old)?;
        if a.cents() != b.cents() || a.cents() < 0 {
            return Err(store::conflict("operating_cost_source_amount_changed"));
        }
    }
    let net =
        OperatingMoneyCents::parse_exact(store::text(cost, "amount_excluding_tax")?, "costNet")?;
    let tax = OperatingMoneyCents::parse_exact(store::text(cost, "tax_cost_amount")?, "costTax")?;
    let gross =
        OperatingMoneyCents::parse_exact(store::text(cost, "amount_including_tax")?, "costGross")?;
    if net.checked_add(tax)?.cents() != gross.cents() {
        return Err(store::conflict("operating_cost_layers_inconsistent"));
    }
    let stage =
        stage(catalog, cost).ok_or_else(|| store::conflict("operating_cost_stage_missing"))?;
    if stage["governance_schema_version"] != 1
        || stage["attributed_stage"] != cost["execution_stage_code"]
        || cost["stage_derived_from_type"] != "CostStageAttributionSnapshot"
        || cost["stage_derived_from_id"] != stage["id"]
        || stage["handled_at"].is_null()
        || stage["handled_by"].is_null()
        || sources::business_day(&stage["evidence_business_date"])?
            != sources::business_day(&cost["occurred_on"])?
    {
        return Err(store::conflict("operating_cost_stage_unverified"));
    }
    let evidence = catalog
        .by(Table::Evidence, "id", &stage["governance_evidence_id"])
        .ok_or_else(|| store::conflict("operating_cost_stage_evidence_missing"))?;
    if evidence["schema_version"] != 1
        || evidence["target_id"] != stage["id"]
        || evidence["payload_hash"] != canonical_hash(&evidence["frozen_payload"])?
    {
        return Err(store::conflict("operating_cost_stage_evidence_changed"));
    }
    Ok(())
}

pub(crate) fn stage<'a>(catalog: &'a Catalog, cost: &Value) -> Option<&'a Value> {
    catalog
        .all(Table::Stage)
        .iter()
        .find(|s| s["cost_record_id"] == cost["id"] && s["status"] == "active")
}

pub(crate) async fn apply(
    session: &mut CommonSession<'_, '_>,
    project: Uuid,
    inputs: &[CostDecisionInput],
    catalog: &Catalog,
    cutoff: NaiveDate,
    restatement: bool,
    actor: &Actor,
) -> Result<(), Error> {
    apply_with_predecessors(
        session,
        project,
        inputs,
        catalog,
        cutoff,
        restatement,
        actor,
        &BTreeMap::new(),
    )
    .await
}

#[expect(
    clippy::too_many_arguments,
    reason = "Source predecessors and explicit inclusion choices are separate transaction inputs."
)]
pub(crate) async fn apply_with_predecessors(
    session: &mut CommonSession<'_, '_>,
    project: Uuid,
    inputs: &[CostDecisionInput],
    catalog: &Catalog,
    cutoff: NaiveDate,
    restatement: bool,
    actor: &Actor,
    predecessors: &BTreeMap<Uuid, Uuid>,
) -> Result<(), Error> {
    let mut seen = BTreeSet::new();
    let members = catalog.members()?;
    for input in inputs {
        let table = match input.target.kind.as_str() {
            "ProjectActualCostRecord" => Table::Cost,
            "SharedCostAllocationResult" => Table::AllocationResult,
            _ => {
                return Err(Error::Unprocessable(
                    "Unsupported classification target".into(),
                ));
            }
        };
        if !seen.insert((table, input.target.id)) {
            return Err(Error::Unprocessable(
                "Duplicate classification target".into(),
            ));
        }
        let original = catalog
            .find(table, input.target.id)
            .ok_or_else(|| store::conflict("operating_classification_target_missing"))?;
        if original["project_id"] != project.to_string() {
            return Err(store::conflict("operating_classification_project_mismatch"));
        }
        sources::assert_expected(
            &sources::reference(table, original)?,
            &serde_json::to_value(&input.target).map_err(|_| Error::Internal)?,
        )?;
        let key = unit_key(table, original)?;
        let head = catalog
            .all(Table::DecisionHead)
            .iter()
            .find(|h| h["project_id"] == project.to_string() && h["unit_key"] == key);
        let head_version = head.and_then(|h| h["row_version"].as_i64()).unwrap_or(0);
        let decision_version = current_decision(catalog, project, &key)
            .map(store::version)
            .transpose()?
            .unwrap_or(0);
        if decision_version != input.expected_version {
            return Err(store::conflict("operating_classification_head_changed"));
        }
        let prior = current_decision(catalog, project, &key);
        if prior.is_some_and(|prior| decision_unchanged(input, prior)) {
            continue;
        }
        if prior.is_some() && !restatement {
            return Err(store::conflict("operating_restatement_required"));
        }
        let decision = input.decision.as_str();
        let role = input.recognition_role.as_str();
        if input.reason_text.trim().is_empty() {
            return Err(Error::Unprocessable(
                "A classification reason is required".into(),
            ));
        }
        for evidence in input
            .evidence_refs
            .iter()
            .chain(input.supporting_source_refs.iter())
        {
            let expected = serde_json::to_value(evidence).map_err(|_| Error::Internal)?;
            if !members
                .iter()
                .any(|(r, _)| sources::assert_expected(r, &expected).is_ok())
            {
                return Err(store::conflict("operating_classification_evidence_changed"));
            }
        }
        if matches!(role, "tax-support" | "evidence-only") {
            if decision != "exclude" {
                return Err(Error::Unprocessable(
                    "Supporting evidence cannot be an included principal".into(),
                ));
            }
            let primary = input.primary_cost_ref.as_ref().ok_or_else(|| {
                Error::Unprocessable("Supporting evidence requires a real primary cost".into())
            })?;
            let actual = catalog
                .find(Table::Cost, primary.id)
                .ok_or_else(|| store::conflict("operating_primary_cost_missing"))?;
            sources::assert_expected(
                &sources::reference(Table::Cost, actual)?,
                &serde_json::to_value(primary).map_err(|_| Error::Internal)?,
            )?;
            if actual["project_id"] != project.to_string() || actual["id"] == original["id"] {
                return Err(store::conflict("operating_primary_cost_invalid"));
            }
        } else if input.primary_cost_ref.is_some() {
            return Err(Error::Unprocessable(
                "Primary recognition cannot name another primary cost".into(),
            ));
        }
        let mut final_source = original.clone();
        if decision == "include" {
            if input.evidence_refs.is_empty() {
                return Err(store::conflict("operating_classification_evidence_missing"));
            }
            if table == Table::Cost {
                if role != "direct-source" {
                    return Err(Error::Unprocessable(
                        "A direct cost requires direct-source recognition".into(),
                    ));
                }
                qualify_cost(session, catalog, original, cutoff).await?;
                if catalog
                    .all(Table::AllocationSource)
                    .iter()
                    .any(|s| s["cost_record_id"] == original["id"] && s["is_current"] == true)
                {
                    return Err(store::conflict("operating_direct_shared_source_overlap"));
                }
                let expected_reason = match original["cost_type"].as_str() {
                    Some("payment-fact") => "actual-payment",
                    Some("expense") => "actual-expense",
                    Some("labor") => "executed-labor",
                    Some("procurement") => "approved-commitment-exception",
                    _ => return Err(store::conflict("operating_primary_monetary_layer_missing")),
                };
                if input.reason_code.as_str() != expected_reason {
                    return Err(Error::Unprocessable(
                        "Classification reason does not match actual producer".into(),
                    ));
                }
                if original["is_included_in_project_cost"] != true {
                    let n=sqlx::query("UPDATE poms.project_actual_cost_record SET record_status='included',is_included_in_project_cost=true,included_at=$1,included_by=$2,row_version=row_version+1,updated_at=$1,updated_by=$2 WHERE id=$3 AND row_version=$4 AND record_status='confirmed' AND NOT is_included_in_project_cost")
                        .bind(clock_now()).bind(actor.id).bind(input.target.id).bind(store::version(original)?).execute(&mut *session.connection).await?.rows_affected();
                    if n != 1 {
                        return Err(store::conflict("operating_cost_consumption_changed"));
                    }
                    final_source =
                        store::row(session.connection, table, input.target.id, false).await?;
                }
            } else {
                if role != "allocation-share"
                    || original["status"] != "active"
                    || original["governance_schema_version"] != 1
                {
                    return Err(store::conflict("operating_allocation_not_frozen"));
                }
                qualify_allocation(session, catalog, original, cutoff, restatement).await?;
                if original["is_included_in_project_cost"] != true {
                    let n=sqlx::query("UPDATE poms.shared_cost_allocation_result SET is_included_in_project_cost=true,included_at=$1,included_by=$2,row_version=row_version+1,updated_at=$1,updated_by=$2 WHERE id=$3 AND row_version=$4 AND status='active' AND NOT is_included_in_project_cost")
                        .bind(clock_now()).bind(actor.id).bind(input.target.id).bind(store::version(original)?).execute(&mut *session.connection).await?.rows_affected();
                    if n != 1 {
                        return Err(store::conflict("operating_allocation_consumption_changed"));
                    }
                    final_source =
                        store::row(session.connection, table, input.target.id, false).await?;
                }
            }
        }
        let id = new_uuid()?;
        let frozen = json!({"schemaVersion":1,"sourceRef":sources::reference(table,&final_source)?,"input":input,"actorId":actor.id,"decidedAt":clock_now()});
        let payload_hash = canonical_hash(&frozen)?;
        store::insert(session,Table::Decision,&json!({"id":id,"project_id":project,"unit_key":key,"source_chain_key":if table==Table::Cost{Some(chain_key(original)?)}else{None},"cost_record_id":if table==Table::Cost{Some(input.target.id)}else{None},"allocation_result_id":if table==Table::AllocationResult{Some(input.target.id)}else{None},"source_row_version":store::version(&final_source)?,"decision":decision,"recognition_role":role,"primary_cost_id":input.primary_cost_ref.as_ref().map(|r|r.id),"reason_code":input.reason_code,"reason_text":input.reason_text,"supporting_source_refs":input.supporting_source_refs,"evidence_refs":input.evidence_refs,"frozen_payload":frozen,"payload_hash":payload_hash,"supersedes_id":predecessors.get(&input.target.id).copied().or(prior.map(|r|store::id(r,"id")).transpose()?),"producer_version":1,"row_version":1,"decided_at":clock_now(),"decided_by":actor.id})).await?;
        let changed = if head_version == 0 {
            sqlx::query("INSERT INTO poms.project_cost_inclusion_head(project_id,unit_key,decision_id,row_version) VALUES($1,$2,$3,1) ON CONFLICT(project_id,unit_key) DO NOTHING").bind(project).bind(&key).bind(id).execute(&mut *session.connection).await?.rows_affected()
        } else {
            sqlx::query("UPDATE poms.project_cost_inclusion_head SET decision_id=$3,row_version=row_version+1 WHERE project_id=$1 AND unit_key=$2 AND row_version=$4 AND decision_id=$5").bind(project).bind(&key).bind(id).bind(i32::try_from(head_version).map_err(|_|Error::Internal)?).bind(prior.map(|r|store::id(r,"id")).transpose()?).execute(&mut *session.connection).await?.rows_affected()
        };
        if changed != 1 {
            return Err(store::conflict("operating_classification_head_changed"));
        }
    }
    Ok(())
}

pub(crate) fn decision_unchanged(input: &CostDecisionInput, prior: &Value) -> bool {
    let Ok(proposed) = serde_json::to_value(input) else {
        return false;
    };
    let previous = &prior["frozen_payload"]["input"];
    if !previous.is_object()
        || prior["source_row_version"].as_i64() != Some(i64::from(input.target.expected_version))
    {
        return false;
    }
    let scalar = [
        "decision",
        "recognitionRole",
        "reasonCode",
        "reasonText",
        "primaryCostRef",
    ];
    if scalar.iter().any(|key| proposed[*key] != previous[*key]) {
        return false;
    }
    for key in ["supportingSourceRefs", "evidenceRefs"] {
        let (Some(a), Some(b)) = (proposed[key].as_array(), previous[key].as_array()) else {
            return false;
        };
        let mut a = a.iter().map(Value::to_string).collect::<Vec<_>>();
        let mut b = b.iter().map(Value::to_string).collect::<Vec<_>>();
        a.sort();
        b.sort();
        if a != b {
            return false;
        }
    }
    true
}

pub(crate) async fn qualify_allocation(
    session: &mut CommonSession<'_, '_>,
    catalog: &Catalog,
    result: &Value,
    cutoff: NaiveDate,
    restatement: bool,
) -> Result<(), Error> {
    let basis = catalog
        .by(Table::AllocationBasis, "id", &result["basis_id"])
        .ok_or_else(|| store::conflict("operating_allocation_basis_missing"))?;
    if basis["governance_schema_version"] != 1
        || basis["status"] != "active"
        || basis["allocation_algorithm"] != "largest-remainder-cents-v1"
    {
        return Err(store::conflict("operating_allocation_basis_unverified"));
    }
    let basis_evidence = catalog
        .by(Table::Evidence, "id", &basis["governance_evidence_id"])
        .ok_or_else(|| store::conflict("operating_allocation_evidence_missing"))?;
    let result_evidence = catalog
        .by(Table::Evidence, "id", &result["governance_evidence_id"])
        .ok_or_else(|| store::conflict("operating_allocation_evidence_missing"))?;
    for (evidence, target) in [(basis_evidence, basis), (result_evidence, result)] {
        if evidence["schema_version"] != 1
            || evidence["target_id"] != target["id"]
            || evidence["payload_hash"] != canonical_hash(&evidence["frozen_payload"])?
        {
            return Err(store::conflict("operating_allocation_evidence_changed"));
        }
    }
    if basis_evidence["frozen_payload"]["algorithm"] != "largest-remainder-cents-v1"
        || result_evidence["frozen_payload"]["basisId"] != basis["id"]
    {
        return Err(store::conflict(
            "operating_allocation_evidence_lineage_changed",
        ));
    }
    for (index, field) in [
        "allocated_amount_excluding_tax",
        "allocated_tax_cost_amount",
        "allocated_amount_including_tax",
    ]
    .iter()
    .enumerate()
    {
        let stored = OperatingMoneyCents::parse_exact(store::text(result, field)?, field)?;
        let value = result_evidence["frozen_payload"]["layers"][index]
            .as_str()
            .ok_or_else(|| store::conflict("operating_allocation_layer_evidence_missing"))?;
        if stored.cents() != OperatingMoneyCents::parse_exact(value, field)?.cents() {
            return Err(store::conflict(
                "operating_allocation_layer_evidence_changed",
            ));
        }
    }
    if !restatement && sources::business_day(&result["effective_at"])? > cutoff {
        return Err(store::conflict("operating_allocation_outside_cutoff"));
    }
    let members = catalog
        .all(Table::AllocationSource)
        .iter()
        .filter(|s| s["basis_id"] == basis["id"])
        .collect::<Vec<_>>();
    if members.is_empty() {
        return Err(store::conflict("operating_allocation_members_missing"));
    }
    let recorded = basis_evidence["frozen_payload"]["sources"]
        .as_array()
        .ok_or_else(|| store::conflict("operating_allocation_source_evidence_missing"))?;
    let actual_ids = members
        .iter()
        .map(|s| store::id(s, "cost_record_id"))
        .collect::<Result<BTreeSet<_>, _>>()?;
    let frozen_ids = recorded
        .iter()
        .map(|s| store::id(&s["cost"], "id"))
        .collect::<Result<BTreeSet<_>, _>>()?;
    if actual_ids != frozen_ids || recorded.len() != members.len() {
        return Err(store::conflict("operating_allocation_source_set_changed"));
    }
    for member in members {
        let cost = catalog
            .by(Table::Cost, "id", &member["cost_record_id"])
            .ok_or_else(|| store::conflict("operating_allocation_member_missing"))?;
        qualify_cost(session, catalog, cost, cutoff).await?;
        if member["cost_row_version"] != cost["row_version"]
            || member["source_payload_hash"] != canonical_hash(&member["source_payload"])?
        {
            return Err(store::conflict("operating_allocation_member_changed"));
        }
        for field in [
            "amount_excluding_tax",
            "tax_cost_amount",
            "amount_including_tax",
        ] {
            if OperatingMoneyCents::parse_exact(store::text(member, field)?, field)?.cents()
                != OperatingMoneyCents::parse_exact(store::text(cost, field)?, field)?.cents()
            {
                return Err(store::conflict(
                    "operating_allocation_member_amount_changed",
                ));
            }
        }
    }
    Ok(())
}

pub(crate) fn validate_pre_effect(
    project: Uuid,
    inputs: &[CostDecisionInput],
    catalog: &Catalog,
) -> Result<(), Error> {
    let mut ids = BTreeSet::new();
    for input in inputs {
        if !ids.insert(input.target.id) {
            return Err(Error::Unprocessable(
                "conflicting_correction_targets".into(),
            ));
        }
        let table = match input.target.kind.as_str() {
            "ProjectActualCostRecord" => Table::Cost,
            "SharedCostAllocationResult" => Table::AllocationResult,
            _ => {
                return Err(Error::BadRequest(
                    "Unsupported classification target".into(),
                ));
            }
        };
        let row = catalog
            .find(table, input.target.id)
            .ok_or_else(|| store::conflict("operating_classification_target_missing"))?;
        if row["project_id"] != project.to_string() {
            return Err(store::conflict("operating_classification_project_mismatch"));
        }
        sources::assert_expected(
            &sources::reference(table, row)?,
            &serde_json::to_value(&input.target).map_err(|_| Error::Internal)?,
        )?;
        let key = unit_key(table, row)?;
        let version = current_decision(catalog, project, &key)
            .map(store::version)
            .transpose()?
            .unwrap_or(0);
        if version != input.expected_version {
            return Err(store::conflict("operating_classification_head_changed"));
        }
    }
    Ok(())
}

/// Only a verified producer transition may carry an explicit old decision to
/// its real successor. No amounts or source rows are synthesized here.
pub(crate) fn transitioned_decisions(
    project: Uuid,
    explicit: &[CostDecisionInput],
    before: &Catalog,
    after: &Catalog,
    transitions: &[crate::project_operating_common::model::VerifiedProducerTransition],
    reason: &str,
) -> Result<(Vec<CostDecisionInput>, BTreeMap<Uuid, Uuid>), Error> {
    let mut output = explicit
        .iter()
        .cloned()
        .map(|d| (d.target.id, d))
        .collect::<BTreeMap<_, _>>();
    let mut predecessors = BTreeMap::new();
    for transition in transitions {
        for old in &transition.before_refs {
            let table = match old.kind.as_str() {
                "ProjectActualCostRecord" => Table::Cost,
                "SharedCostAllocationResult" => Table::AllocationResult,
                _ => continue,
            };
            let Some(old_row) = before.find(table, old.id) else {
                continue;
            };
            if old_row["project_id"] != project.to_string() {
                continue;
            }
            let successors = transition
                .after_refs
                .iter()
                .filter(|new| {
                    new.kind == old.kind
                        && after.find(table, new.id).is_some_and(|r| {
                            r["project_id"] == project.to_string()
                                && (new.id == old.id
                                    || r[if table == Table::Cost {
                                        "supersedes_record_id"
                                    } else {
                                        "supersedes_id"
                                    }] == old.id.to_string())
                        })
                })
                .collect::<Vec<_>>();
            if successors.len() != 1 {
                return Err(store::conflict(
                    "operating_classification_transition_ambiguous",
                ));
            }
            let new = successors[0];
            if new.id == old.id
                && new.row_version == old.row_version
                && new.payload_hash == old.payload_hash
            {
                continue;
            }
            let new_row = after.find(table, new.id).ok_or(Error::Internal)?;
            let old_decision = current_decision(before, project, &unit_key(table, old_row)?);
            let Some(prior) = old_decision else { continue };
            let target = crate::project_operating_common::model::ExpectedRef {
                kind: new.kind.clone(),
                id: new.id,
                expected_version: new.row_version,
                payload_hash: new.payload_hash.clone(),
            };
            let new_head = current_decision(after, project, &unit_key(table, new_row)?)
                .map(store::version)
                .transpose()?
                .unwrap_or(0);
            let mut decision=match output.remove(&old.id){Some(mut value)=>{value.target=target.clone();value.expected_version=new_head;value},None=>serde_json::from_value(json!({"target":target,"expectedVersion":new_head,"decision":prior["decision"],"recognitionRole":prior["recognition_role"],"reasonCode":prior["reason_code"],"reasonText":reason,"primaryCostRef":prior["primary_cost_id"].as_str().and_then(|id|Uuid::parse_str(id).ok()).and_then(|id|after.find(Table::Cost,id)).map(|r|sources::reference(Table::Cost,r)).transpose()?.map(|mut r|{let version=r["rowVersion"].take();r.as_object_mut().map(|m|m.remove("rowVersion"));r["expectedVersion"]=version;r}),"supportingSourceRefs":prior["supporting_source_refs"],"evidenceRefs":prior["evidence_refs"]})).map_err(|_|Error::Internal)?};
            decision.primary_cost_ref = decision
                .primary_cost_ref
                .as_ref()
                .map(|r| rebind_reference(r, transitions, after))
                .transpose()?;
            decision.supporting_source_refs = decision
                .supporting_source_refs
                .iter()
                .map(|r| rebind_reference(r, transitions, after))
                .collect::<Result<Vec<_>, _>>()?;
            decision.evidence_refs = decision
                .evidence_refs
                .iter()
                .map(|r| rebind_reference(r, transitions, after))
                .collect::<Result<Vec<_>, _>>()?;
            for reference in &transition.evidence_refs {
                decision
                    .evidence_refs
                    .push(crate::project_operating_common::model::ExpectedRef {
                        kind: reference.kind.clone(),
                        id: reference.id,
                        expected_version: reference.row_version,
                        payload_hash: reference.payload_hash.clone(),
                    });
            }
            predecessors.insert(new.id, store::id(prior, "id")?);
            output.insert(new.id, decision);
        }
    }
    Ok((output.into_values().collect(), predecessors))
}

fn rebind_reference(
    reference: &crate::project_operating_common::model::ExpectedRef,
    transitions: &[crate::project_operating_common::model::VerifiedProducerTransition],
    after: &Catalog,
) -> Result<crate::project_operating_common::model::ExpectedRef, Error> {
    for transition in transitions {
        if !transition.before_refs.iter().any(|old| {
            old.kind == reference.kind
                && old.id == reference.id
                && old.row_version == reference.expected_version
                && old.payload_hash == reference.payload_hash
        }) {
            continue;
        }
        let candidates = transition
            .after_refs
            .iter()
            .filter(|new| new.kind == reference.kind)
            .collect::<Vec<_>>();
        let selected = candidates
            .iter()
            .find(|new| new.id == reference.id)
            .copied()
            .or_else(|| {
                if candidates.len() == 1 {
                    Some(candidates[0])
                } else {
                    let table = match reference.kind.as_str() {
                        "ProjectActualCostRecord" => Table::Cost,
                        "SharedCostAllocationResult" => Table::AllocationResult,
                        "CostStageAttributionSnapshot" => Table::Stage,
                        "AccountingTaxTreatmentSnapshot" => Table::Tax,
                        _ => return None,
                    };
                    candidates
                        .iter()
                        .find(|new| {
                            after.find(table, new.id).is_some_and(|row| {
                                row[if table == Table::Cost {
                                    "supersedes_record_id"
                                } else {
                                    "supersedes_id"
                                }] == reference.id.to_string()
                            })
                        })
                        .copied()
                }
            });
        if let Some(new) = selected {
            return Ok(crate::project_operating_common::model::ExpectedRef {
                kind: new.kind.clone(),
                id: new.id,
                expected_version: new.row_version,
                payload_hash: new.payload_hash.clone(),
            });
        }
        if !candidates.is_empty() {
            return Err(store::conflict(
                "operating_correction_reference_transition_ambiguous",
            ));
        }
    }
    Ok(reference.clone())
}
